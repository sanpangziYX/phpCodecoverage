package test;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.alibaba.fastjson.*;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.io.File;

@Controller
public class ReadFile {
	/*
	 * 读取指定路径下的文件名和目录名
	 */
	@ResponseBody
	@RequestMapping("/getList")
	public String getFileList(HttpServletRequest request, HttpServletResponse response)
			throws UnsupportedEncodingException {

		String depart = URLDecoder.decode(request.getParameter("depart"), "UTF-8");
		String env = URLDecoder.decode(request.getParameter("env"), "UTF-8");
		String pro = URLDecoder.decode(request.getParameter("pro"), "UTF-8");

		List<String> list = new ArrayList<String>();
		try {
			// File file = new
			// File("/usr/local/tomcat8.0.53/webapps/ROOT/report/"+File.separator+depart+File.separator+pro+File.separator+env);
			//File file = new File("C:/Users/lenovo/Desktop/report" + File.separator + depart + File.separator + pro+ File.separator + env);
			//此处服务器文件目录tomcat
			File file = new File(File.separator+"usr"+File.separator+"local"+File.separator+"tomcat8.0.53"+File.separator+"webapps"+File.separator+"ROOT"+File.separator+"report"+File.separator+depart+File.separator+pro+File.separator+env);
			//File file = new File(File.separator+"usr"+File.separator+"local"+File.separator+"tomcat8.0.53"+File.separator+"webapps"+File.separator+"ROOT"+File.separator+"report"+File.separator+depart+File.separator+pro);

			File[] fileList = file.listFiles();

			for (int i = 0; i < fileList.length; i++) {
				if (fileList[i].isFile()) {
					String fileName = fileList[i].getName();
					System.out.println("文件：" + fileName);
				}
				if (fileList[i].isDirectory()) {
					String fileName = fileList[i].getName();
					list.add(fileName);
					System.out.println("目录：" + fileName);
				}
			}
			Collections.sort(list);//升序排列
			Collections.reverse(list);//降序
			response.addHeader("Access-Control-Allow-Origin", "*");//跨域
			response.addHeader("Access-Control-Allow-Method", "POST,GET");
			String json = JSON.toJSONString(list);
			response.encodeURL("UTF-8");
			System.out.println("json:---" + json);
			return json;
		} catch (Exception e) {
			return null;
		}

	}
}

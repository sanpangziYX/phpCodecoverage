package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import org.apache.log4j.Logger;
import org.json.JSONObject;

public class GetRequest {

	static final Logger logger = Logger.getLogger("D");

	/**
	 * 根据指定url，编码获得字符串
	 * 
	 * @param address
	 * @param Charset
	 * @return
	 */
	public static String getStringByConAndCharset(String address, String Charset) {

		StringBuffer sb;
		try {
			URL url = new URL(address);

			URLConnection con = url.openConnection();
			BufferedReader bw = new BufferedReader(new InputStreamReader(con.getInputStream(), Charset));
			String line;
			sb = new StringBuffer();
			while ((line = bw.readLine()) != null) {
				sb.append(line + "\n");
			}
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
			sb = new StringBuffer();
		}

		return sb.toString();
	}

	/**
	 * 通过post方式获取页面源码
	 * 
	 * @param urlString
	 *            url地址
	 * @param paramContent
	 *            需要post的参数
	 * @param chartSet
	 *            字符编码（默认为ISO-8859-1）
	 * @return
	 * @throws IOException
	 */
	public static String postUrl(String urlString, String paramContent, String chartSet, String contentType) {
		long beginTime = System.currentTimeMillis();
		if (chartSet == null || "".equals(chartSet)) {
			chartSet = "ISO-8859-1";
		}

		StringBuffer result = new StringBuffer();
		BufferedReader in = null;

		try {
			URL url = new URL((urlString));
			URLConnection con = url.openConnection();

			// 设置链接超时
			con.setConnectTimeout(3000);
			// 设置读取超时
			con.setReadTimeout(3000);
			// 设置参数
			con.setDoOutput(true);
			if (contentType != null && !"".equals(contentType)) {
				con.setRequestProperty("Content-type", contentType);
			}

			OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream(), chartSet);
			writer.write(paramContent);
			writer.flush();
			writer.close();
			in = new BufferedReader(new InputStreamReader(con.getInputStream(), chartSet));
			String line = null;
			while ((line = in.readLine()) != null) {
				result.append(line + "\r\n");
			}
			in.close();
		} catch (MalformedURLException e) {
			logger.error("Unable to connect to URL: " + urlString, e);
		} catch (SocketTimeoutException e) {
			logger.error("Timeout Exception when connecting to URL: " + urlString, e);
		} catch (IOException e) {
			logger.error("IOException when connecting to URL: " + urlString, e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception ex) {
					logger.error("Exception throws at finally close reader when connecting to URL: " + urlString, ex);
				}
			}
			long endTime = System.currentTimeMillis();
			logger.info("post用时：" + (endTime - beginTime) + "ms");
		}
		return result.toString();
	}

	public String Get(String param) {
		try {
			// 传入参数
			String realUrl = param;
			URL url = new URL(realUrl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			// 在连接之前设置属性
			// Content-Type实体头用于向接收方指示实体的介质类型，指定HEAD方法送到接收方的实体介质类型，或GET方法发送的请求介质类型
			conn.setRequestProperty("Content-Type", "application/json");
			// 设置打开与此URLConnection引用的资源的通信链接时使用的指定超时值（以毫秒为单位）
			conn.setConnectTimeout(10000);
			// 将读取超时设置为指定的超时时间，以毫秒为单位。
			// conn.setReadTimeout(60000);
			conn.setRequestMethod("GET");
			// Post 请求不能使用缓存
			conn.setUseCaches(false);
			// 建立连接
			conn.connect();
			// 获取响应
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			String result = "";
			while ((line = reader.readLine()) != null) {
				result += line;
			}
			reader.close();
			conn.disconnect();
			return result;
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (SocketTimeoutException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

}

package test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileObject {
	private String id;
	private String name;
	private String size;
	private String date;
	private List<FileObject> children = new ArrayList<FileObject>();

	public void setId(String id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getId() {
		return id;
	}

	public String getDate() {
		return date;
	}

	public List<FileObject> getChildren() {
		return children;
	}

	public String getName() {
		return name;
	}

	public String getSize() {
		return size;
	}
}

package test;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
// @RequestMapping("/mvc")
public class SpringMVC {

	public static void main(String[] args) {
		GetRequest gr = new GetRequest();
		String result = gr.postUrl("huoqushujudeURL", "paramContent", "chartSet", "contentType");

	}

	@RequestMapping("/index")
	public String hello() {
		return "index";
	}

	@RequestMapping("/indexaaa")
	public String index() {
		GetRequest gr = new GetRequest();
		String result = gr.postUrl("huoqushujudeURL", "paramContent", "chartSet", "contentType");
		DoData doData = new DoData();
		String data = doData.parseJSONArray(result);
		return data;
	}
}

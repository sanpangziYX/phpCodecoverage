package test;

import org.json.JSONArray;
import org.springframework.core.env.SystemEnvironmentPropertySource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.chainsaw.Main;
import org.json.*;

/**
 * 处理respone的结果 人工筛选出属于php的项目
 * 
 * @author lenovo
 *
 */
public class DoData {
	/**
	 * 处理返回的json
	 * 
	 * @param json
	 */
	public static void main(String[] args) {
		GetRequest gr = new GetRequest();
		String result = gr.Get("http://deploy.xesv5.com/getappdata?limit=2&offset=1");
		System.out.println("result:---:" + result);
		String json = "[{\"name\":\"胡小威-A\" , \"age\":20 , \"male\":true},{\"name\":\"赵小亮-B\",\"age\":22 , \"male\":false}]";
		DoData doData = new DoData();
		doData.parseJSONArray(json);
		System.out.println("main:" + doData.parseJSONArray(json));
	}

	public String parseJSONArray(String json) {
		JSONObject jsonObject = new JSONObject();
		// 筛选项目逻辑处理-需要的项目放入list
		List<String> needId = Arrays.asList("20");
		try {
			JSONArray jsonArray = new JSONArray(json);
			for (int i = 0; i < jsonArray.length(); i++) {
				jsonObject = jsonArray.getJSONObject(i);
				String name = jsonObject.getString("name");
				String a = name.split("-")[0];
				String b = name.split("-")[1];
				System.out.println("----:" + name);
				System.out.println("----:" + a);
				System.out.println("----:" + b);
				jsonObject.put("name-a", a);
				jsonObject.put("name-b", b);
				System.out.println(jsonObject.toString());

			}
			return jsonObject.toString();
		} catch (JSONException e) {
			e.printStackTrace();
			return null;
		}
	}

	public void needProId() {

	}
}

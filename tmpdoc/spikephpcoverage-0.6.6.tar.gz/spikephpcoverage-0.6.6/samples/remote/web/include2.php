<?php

    class Temp {

    }

    function f1() {
        echo "4";
    }
    echo "3";
?>
